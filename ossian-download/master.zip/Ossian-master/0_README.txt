
====================================                                                           
Ossian Speech Synthesis Toolkit                  
Simple4All Consortium                      
Copyright (c) 2013-2014                          
All Rights Reserved.     
====================================                       
                                                                        
THE UNIVERSITY OF EDINBURGH AND THE CONTRIBUTORS TO THIS WORK         
DISCLAIM ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING       
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT    
SHALL THE UNIVERSITY OF EDINBURGH NOR THE CONTRIBUTORS BE LIABLE      
FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES     
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN    
AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,           
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF        
THIS SOFTWARE.                                                        

 Authors: Simple4All consortium members          
 Date:    November 2013-2014                      
 Contact: owatts@staffmail.ed.ac.uk                 


Please point an HTML browser at ./doc/build/html/index.html for some tips and pointers.