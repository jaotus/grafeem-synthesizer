Corpus
------

Data processed by Ossian is held in a ``corpus`` object.




.. autoclass:: main.Corpus.Corpus
    :members:
    :undoc-members:
    



Utterance
---------

Utterance struct held herecd


Various inherited methods are specialised to act on the ``data`` attribute. These 'rerouted' 
methods are not documented here.

.. todo:: Is there a more proper way to do this?  


.. autoclass:: main.Utterance.Utterance
    :members:
    :undoc-members:
    :exclude-members:  iterdescendants, pretty_print, remove, get, set, xpath, insert, has_attribute
    
    
    
    
