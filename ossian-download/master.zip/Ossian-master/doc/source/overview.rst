

===============
Overview
===============



.. ---- These are just comments ----:
.. But it's not straightforward! The whole Festival system seems to be designed to be complicated and keep non-geeks out!

..            --digitaltoast

.. [http://ubuntuforums.org/showthread.php?t=751169&page=12]