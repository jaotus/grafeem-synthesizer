#!/usr/bin/env python
# -*- coding: utf-8 -*-
## Project: Simple4All - June 2013 - www.simple4all.org 
## Contact: Oliver Watts - owatts@staffmail.ed.ac.uk
## Contact: Antti Suni - Antti.Suni@helsinki.fi

# 
# The processors in this module integrate machine learning models 
# implemented in scikit-learn (http://scikit-learn.org/stable)
# 

#import tempfile 
from UtteranceProcessor import *
#from util.NodeProcessors import *
#from FeatureDumper import *
#from util.DecisionTree import *
import logging


import numpy as np
import pickle
from sklearn import tree
from sklearn.feature_extraction import DictVectorizer




class SKLDecisionTree(UtteranceProcessor):


    def load(self):  

        self.min_samples_leaf = int(self.config.get('min_samples_leaf', '10')) 
        ## Set other tree building defaults here?

        self.model = None

        self.model_file = os.path.join(self.get_location(), "model.pkl") ## TODO: standard filename in const.py?
        
        if os.path.isfile(self.model_file):
        
            ## If the model file exists, count it as trained -- get everything from processor dir:
            f = open(self.model_file, 'rb')
            [self.x_vectoriser, self.y_vectoriser, self.model] = pickle.load(f)
            f.close()
                 
        ## For now, use context list inside the recipe: 
        if 'contexts' not in self.config:
            sys.exit('config for SKLDecisionTree should contain a contexts section') 
        self.context_list = self.config['contexts'].items()                   
        
          
        assert 'output_attribute' in self.config        
        self.output_attribute = self.config['output_attribute']

        ## Check response exists in context list, and find its index:
        self.feature_names = [name for (name, xpath) in self.context_list]  
        assert 'response' in self.feature_names
        reponse_index = self.feature_names.index('response')
        
        ## Ensure response is at *start* of context list:
        response = self.context_list[reponse_index]
        del self.context_list[reponse_index]
        self.context_list.insert(0, response)


    def process_utterance(self, utt):
        
        assert self.model, 'Cannot apply processor %s until its model is trained'%(self.conf['processor_name'])

      
        for node in utt.xpath(self.config["target_nodes"]):
                   
            input_features = dict(node.get_context_vector(self.context_list))
            input_features = self.x_vectoriser.transform(input_features).toarray()
             ## no need to remove response -- will be ignored if not in x_vectoriser

            decision = self.model.predict(input_features)
            
            ### Skip this -- assume response is numeric:
            #decision = self.y_vectoriser.inverse_transform(decision) 

            '''
            ##PROBLEM: 0 values not put in inverse transformed dict:
            >>> print yv.inverse_transform(yv.transform([{'response': 3}]))
            [{'response': 3.0}]
            >>> print yv.inverse_transform(yv.transform([{'response': 0.0}]))
            [{}]
            '''
            
            decision = decision[0] ## prediction is a list of 1 int

            # prososdy labeling is numeric but quantized for HTS. so 2.0 != 2 for contextual features
            # does this break other modules?
            try:
                if decision == int(decision):
                    decision = int(decision)
            except:
                pass

            node.set(self.output_attribute, unicode(decision)) 
                        ## TODO: where is best place to convert to unicode?


    def do_training(self, speech_corpus, text_corpus):
        
        if self.model:  ## if already trained...
            return

        ## 1) get data:
        #### [Added dump_features method to Utterance class, use that: ]
        x_data = []
        y_data = []
        for utterance in speech_corpus:
            
            utt_feats = utterance.dump_features(self.config["target_nodes"], \
                                                self.context_list, return_dict=True)
            for example in utt_feats:
                assert 'response' in example,example
                y_data.append({'response': example['response']})
                del example['response']
                x_data.append(example)
        
        ## Handle categorical features (strings) but to keep numerical ones 
        ## as they are:
        
        x_vectoriser = DictVectorizer()
        x_data = x_vectoriser.fit_transform(x_data).toarray()
        
        y_vectoriser = DictVectorizer()
        y_data = y_vectoriser.fit_transform(y_data).toarray()
      
        ## 2) train classifier:
        model = tree.DecisionTreeClassifier(min_samples_leaf=self.min_samples_leaf)

        model.fit(x_data, y_data) 
        print '\n Trained classifier: '
        print model
        print '\n Trained x vectoriser:'
        print x_vectoriser
        print 'Feature names:'
        print x_vectoriser.get_feature_names()
        print '\n Trained y vectoriser:'
        print y_vectoriser
        print 'Feature names:'
        print y_vectoriser.get_feature_names()
        
        ## 3) Save classifier by pickling:
        output = open(self.model_file, 'wb')
        pickle.dump([x_vectoriser, y_vectoriser, model], output)
        output.close()        
        
        ## Write ASCII tree representation (which can be plotted):
        tree.export_graphviz(model, out_file=self.model_file + '.dot',  \
                                     feature_names=x_vectoriser.get_feature_names())
        
        self.load() ## reload -- get self.cart etc 
        
