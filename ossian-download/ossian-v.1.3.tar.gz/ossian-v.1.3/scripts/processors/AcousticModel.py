#!/usr/bin/env python
# -*- coding: utf-8 -*-
## Project: Simple4All - January 2013 - www.simple4all.org 
## Contact: Oliver Watts - owatts@staffmail.ed.ac.uk
## Contact: Antti Suni - Antti.Suni@helsinki.fi


from UtteranceProcessor import *
from util.NodeProcessors import *

from distutils.spawn import find_executable

class AcousticModel(UtteranceProcessor):
    '''
    Specific to STRAIGHT -- TODO: make a more general AcousticModel and subclass it for 
    STRAIGHT, glottHMM, etc.?
    Or can we code the stream names in config, and have this class agnostic about number
    and names of streams? Some special cases, like VUV?
    '''
    def load(self): 

        ## Set path to HTS binaries from voice resources:
        self.hts_dir = self.voice_resources.path[c.BIN]

        self.input_label_filetype = self.config.get('input_label_filetype', 'lab')
        self.acoustic_feature_filetype = self.config.get('acoustic_feature_filetype', 'cmp')
        self.output_filetype = self.config.get('output_filetype', 'wav')

        self.acoustic_subrecipe = self.config.get('acoustic_subrecipe', 'standard_voicebuild')


        self.winfiles = []
        for (window, default_window) in [  ('static_window', '1.0'),  \
                                           ('delta_window', '-0.5 0.0 0.5'), \
                                           ('delta_delta_window', '1.0 -2.0 1.0')]:
            fname = os.path.join(self.get_location(), window + '.win')
            data = self.config.get(window, default_window)
            length = len(data.strip().split())
            data = '%s %s'%(length, data)
            writelist([data], fname)
            self.winfiles.append(fname)
            
        self.training_settings = {}
        if 'training_settings' in self.config:
            self.training_settings = self.config['training_settings']        
                  
        ## Try loading model:
        self.trained = True
        self.model_dir = os.path.join(self.get_location()) 

        
        if not os.path.isdir(self.model_dir):
            self.trained = False
            
            
        ## verify all the parts needed are present: if the model files exists, count it as trained:
        complete = True
        
        #for component in ['tree-logF0.inf', 'tree-mcep.inf', \
        #                  'duration.pdf', 'logF0.pdf', 'mcep.pdf']:
        ## ANT: until stream generalization is done, just check duration
        for component in ['tree-duration.inf', 'duration.pdf']:
            if not os.path.isfile(os.path.join(self.model_dir, component)):
                complete = False
                self.trained = False
                #print 'component missing: %s'%(component)

            
        ## get attributes from config, converting type and supplying defaults:
        self.vuv = self.config.get('vuv', '0.50') ## high means more unvoiced

        ## get training configuration defined in feature extractor, for glotthmm
        self.stream_definitions = ConfigObj(self.get_location()+"/../speech_feature_extractor/acoustic_feats.cfg")
       
        
    def process_utterance(self, utt):  ### sptk for engine 1.07:

        if utt.has_attribute("waveform"):    
            #print "Utt has a natural waveform -- don't synthesise"
            return
            
        if not self.trained:
            print 'WARNING: Cannot apply processor %s till model is trained'%(self.processor_name)
            return


        label = utt.get_filename(self.input_label_filetype) 
        owave = utt.get_filename(self.output_filetype)
        
        comm = self.hts_dir + '/hts_engine'
        
        comm += "  -td %s/tree-duration.inf "%(self.model_dir)
        comm += "  -md %s/duration.pdf "%(self.model_dir)
        
        comm += "  -tf %s/tree-logF0.inf "%(self.model_dir)
        comm += "  -mf %s/logF0.pdf "%(self.model_dir)
        
        comm += "  -tm %s/tree-mcep.inf "%(self.model_dir)
        comm += "  -mm %s/mcep.pdf "%(self.model_dir)
        
        ## windows:
        for stream in ['f', 'm']:
            for winfile in self.winfiles:
                comm += "  -d%s %s "%(stream, winfile)

        comm += " -b 1.5 " ## for postfiltering 
        comm += "  -u %s "%(self.vuv)
        comm += "  -ow %s "%(owave)
        comm += "    %s > %s.log"%(label, label)
        
        os.system(comm)

   
      
    def do_training(self, speech_corpus, text_corpus):
        """
        This is nearly identical to Aligner's method of the same name -- how to refactor?
        Differences -- question_file, messages (aligner -> AM)
        """
        
        ## Double check not trained:
        if self.trained:
            print "Acoustic model already trained!"
            return

        ## Else proceed to training:
        train_location = self.model_dir + "/training"        
        print "\n          Training acoustic model -- see %s/log.txt\n"%(train_location) 
        if os.path.isdir(train_location):
            shutil.rmtree(train_location)  ## delete any existing stuff for a clean start
        os.makedirs(train_location)
      
        feature_dir = os.path.join(self.voice_resources.path[c.TRAIN], \
                                                self.acoustic_feature_filetype)
        label_dir = os.path.join(self.voice_resources.path[c.TRAIN], \
                                                self.input_label_filetype)

        question_file = os.path.join(self.voice_resources.path[c.TRAIN], 'questions.hed')
        if not os.path.isfile(question_file):
            sys.exit('Question file doe not exist at %s'%(question_file))

        ## Locate training script and default training config:
        script_dir = self.voice_resources.path[c.ACOUSTIC_MODELLING_SCRIPT]
        config_dir = self.voice_resources.path[c.ACOUSTIC_MODELLING_CONFIG]
        training_script = os.path.join(script_dir, self.acoustic_subrecipe+'.sh')
        default_config = os.path.join(config_dir, self.acoustic_subrecipe + '.cfg')

        ## Specialise the default config with settings made in the voice recipe, then
        ## write to bash config file for use by alignment script:
        train_config_fname = os.path.join(train_location, 'train.cfg')
        train_config = ConfigObj(default_config)
        train_config.update(self.training_settings)

         # get stream definitions from feature extractor too (glotthmm version only)
        train_config.update(self.stream_definitions)

        write_bash_config(train_config, train_config_fname)


        
        ## Call the training script:
        command = """%s %s %s %s %s %s %s | tee %s/log.txt  \
                    | grep 'Model training'"""%(training_script, \
                            feature_dir, label_dir, question_file, self.hts_dir,\
                            train_location, train_config_fname, train_location)   
        #print command
        success = os.system(command)
        if success != 0:
            sys.exit('AM training failed')
            
        ## Copy the aligner files that need to be preserved:
        final_model_dir = os.path.join(train_location, 'final_model', 'engine')
        ## for SPTK the resulting files will contain: 
        ## duration.pdf logF0.pdf mcep.pdf tree-duration.inf tree-logF0.inf tree-mcep.inf
        for item in os.listdir(final_model_dir):
            shutil.copy(os.path.join(final_model_dir, item), self.model_dir)
        
        self.load() ## to get new model filenames into self.model's values



class AcousticModelGlott(AcousticModel):


    def process_utterance(self, utt):
        from numpy import loadtxt, savetxt,exp, mean,median
        if utt.has_attribute("waveform"):
            #print "Utt has a natural waveform -- don't synthesise"
            return



        if not self.trained:
            print 'WARNING: Cannot apply processor %s till model is trained'%(self.processor_name)
            return
        
        self.model_dir = os.path.join(self.get_location())
        bin_dir = self.voice_resources.path[c.BIN]
        
        label = utt.get_filename(self.input_label_filetype) 
        owave = utt.get_filename(self.output_filetype)
        
        # generate parameters with hts_engine, one stream at the time
        feats = str.split(self.stream_definitions["STREAM_NAMES"])
        
        self.vuv = 0.4
        for f in feats:
            comm = self.hts_dir + '/hts_engine '
            comm += "  -td %s/tree-duration.inf "%(self.model_dir)
            comm += "  -md %s/duration.pdf "%(self.model_dir)

            comm += "  -tf %s/tree-F0.inf "%(self.model_dir)
            comm += "  -mf %s/F0.pdf "%(self.model_dir)
        
            comm += "  -tm %s/tree-%s.inf "%(self.model_dir, f)
            comm += "  -mm %s/%s.pdf "%(self.model_dir,f)

            comm += "  -ow /tmp/tmp.wav"        
            comm += "  -om /tmp/tmp.%s"%(f)    
            comm += "  -of /tmp/tmp.F0"    
            
            ## windows:
            for stream in ['f', 'm']:
                for winfile in self.winfiles:
                    comm += "  -d%s %s "%(stream, winfile)
            comm += " -b 0.0 " ## for postfiltering 
            comm += "  -u %s "%(self.vuv)
            #comm += "  -ow %s "%(owave)
            comm += "    %s > %s.log"%(label, label)
        
            os.system(comm)

        # process parameters
            
        f0 = []
        for f in reversed(feats):
            os.system(bin_dir+"/x2x +fa /tmp/tmp."+f+" >/tmp/tmp_a."+f)
            if f == "F0":
                f0 = loadtxt('/tmp/tmp_a.F0')
                f0[f0>0]=exp(f0[f0>0])
                f0[f0<=0] = 0
                savetxt("/tmp/tmp_a.f0", f0.astype('float'), fmt = '%.8f')



            if f == "mcep":
                # get orders from acoustic config
                mcep_order = str(29)
                lsf_order =str(30)
                warp = str(0.35)
                os.system(bin_dir+"/freqt -a "+warp+" -A 0.0 -m "+mcep_order+" -M 120 </tmp/tmp.mcep | "+bin_dir+"/c2acr -m 120 -M "+lsf_order+" | "+bin_dir+"/levdur -m "+lsf_order+ " >/tmp/tmp.lpc")
                os.system(bin_dir+"/lpc2lsp -k -m "+lsf_order+" -n 512 -s 16 -p 1 /tmp/tmp.lpc >/tmp/tmp.LSF");
                os.system(bin_dir+"/x2x +fa /tmp/tmp.LSF >/tmp/tmp_a.LSF")

        lsf = loadtxt("/tmp/tmp_a.LSF")

        
        savetxt("/tmp/tmp_a.LSF", lsf.astype('float'), fmt = '%8f')
        # Synthesize 
        conf_dir = self.get_location()+"/../speech_feature_extractor"
        comm = self.voice_resources.path['GLOTT']+"/Synthesis /tmp/tmp_a "+conf_dir+"/main_config.cfg "+conf_dir+"/user_config.cfg"
        os.system(comm)
        os.system("mv /tmp/tmp_a.syn.wav "+owave)
        
   
