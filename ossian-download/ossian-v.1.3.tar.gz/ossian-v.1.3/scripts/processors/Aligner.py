#!/usr/bin/env python
# -*- coding: utf-8 -*-
## Project: Simple4All - January 2013 - www.simple4all.org 
## Contact: Oliver Watts - owatts@staffmail.ed.ac.uk
## Contact: Antti Suni - Antti.Suni@helsinki.fi


from processors.UtteranceProcessor import *
from util.NodeProcessors import *
#from util.NodeProcessors import add_states_from_label
# from util.Aligner import *
import default.const as c

class SegmentAligner(UtteranceProcessor):

    def load(self):  

        ## Set path to HTS binaries from voice resources:
        self.hts_dir = self.voice_resources.path[c.BIN]

        ## get filetypes from config:
        self.target_nodes = self.config.get('target_nodes', '//Token')
        self.target_attribute = self.config.get('target_attribute', 'safetext')
        self.input_label_filetype = self.config.get('input_label_filetype', 'in_lab')
        self.acoustic_feature_filetype = self.config.get('acoustic_feature_filetype', 'mfcc')
        self.output_label_filetype = self.config.get('output_label_filetype', 'out_lab')

        self.silence_symbol = self.config.get('silence_symbol', 'sil')
        self.min_silence_duration = int(self.config.get('min_silence_duration', 50))
        self.silence_tag = self.config.get('silence_tag', 'has_silence')
        
        self.n_training_utts = self.config.get('n_training_utts', 0)

        self.acoustic_subrecipe = self.config.get('acoustic_subrecipe', 'standard_alignment')
        
        ## get manual alignment lexicon entries:
        self.alignment_lexicon_entries = {}
        if 'alignment_lexicon_entries' in self.config:
            self.alignment_lexicon_entries = self.config['alignment_lexicon_entries']
        ## make sure all entries are lists -- single entries just end up as unicodes:
        for (key, value) in self.alignment_lexicon_entries.items():
            if not isinstance(value, list):
               self.alignment_lexicon_entries[key] = [ value ]
        
        self.training_settings = {}
        if 'training_settings' in self.config:
            self.training_settings = self.config['training_settings']        

        # acoustic features settings, glotthmm only
        self.stream_definitions = ConfigObj(self.get_location()+"/../speech_feature_extractor/acoustic_feats.cfg")

        ## Try to find aligner components to work out if we are trained:
        self.trained = True
        self.model_dir = os.path.join(self.get_location())
        self.model = {}  ## paths to files containing model components

        for component in ["cmp.mmf", "general.conf", "lexicon.txt", 'modellist.mono']:

            fpath = os.path.join(self.get_location(), component)
            
            if os.path.isfile(fpath):
                self.model[component] = fpath 
            else:
                self.trained = False
            
            ##setattr(self, component, fpath)



    def process_utterance(self, utt):
        if not self.trained:
            sys.exit('Aligner: must be trained before utterances can be processed.')
            
        if not (utt.has_external_data(self.acoustic_feature_filetype) and \
                                        utt.has_external_data(self.input_label_filetype)):
            print "No initial label and/or features for %s"%(utt.get('utterance_name'))
            utt.set("status", "alignment_failed")
            return            
            
        ## Try to align from audio:
        in_lab_dir = utt.get_dirname(self.input_label_filetype) ## dir (not file) for HVite
        out_lab_dir = utt.get_dirname(self.output_label_filetype)## dir (not file) for HVite

        feat_file = utt.get_filename(self.acoustic_feature_filetype) 
        logfile = utt.get_filename("align_log")  ## hardcoded!!!

        """
        ## bypass utts which contain oov words (actually, letters):
        label_seq = readlist(utt.get_filename(self.input_label_filetype))
         for seg in label_seq:
             if seg not in self.model['python_lex']:
                 sys.exit('Can\'t align utterance: segment %s not trained in model'%(seg)) ## 
        """
        
        command = """%s/HVite -l %s -y %s -X %s -C %s -a -m -L %s -T 1 -o S -H %s \
                                                        %s %s %s > %s"""%(self.hts_dir,\
                     out_lab_dir, self.output_label_filetype, self.input_label_filetype, \
                    self.model['general.conf'], in_lab_dir, self.model['cmp.mmf'], \
                    self.model['lexicon.txt'], self.model['modellist.mono'], feat_file, \
                     logfile)
        os.system(command)
        
        time_lab = utt.get_filename(self.output_label_filetype)
        if not os.path.isfile(time_lab):
            print "No alignment produced for %s"%(utt.get('utterance_name'))
            utt.set("status", "alignment_failed")
            return
            
        ## If label has been made, merge its info into the utt XML:
        add_segments_from_label(utt, input_label=self.output_label_filetype,\
                                 target_nodes=self.target_nodes, \
                                 target_attribute=self.target_attribute)
                                 
        propagate_start_and_end_times_up_tree(utt) ## to get e.g. token start and end etc.
        
        remove_short_silent_segments(utt, target_attribute=self.target_attribute, \
                                        silence_symbol=self.silence_symbol,  \
                                        min_silence_duration=self.min_silence_duration)
            
        propagate_silence_tag_up_tree(utt, silence_symbol=self.silence_symbol, \
                                        target_attribute=self.target_attribute, \
                                        output_attribute=self.silence_tag)  
         

    def do_training(self, speech_corpus, text_corpus):
        
        ## Double check not trained:
        if self.trained:
            print "Aligner already trained!"
            return

        ## Else proceed to training:
        train_location = self.model_dir + "/training"        
        print "\n          Training aligner -- see %s/log.txt\n"%(train_location) 
        if not os.path.isdir(train_location):
            os.makedirs(train_location)
      
        feature_dir = os.path.join(self.voice_resources.path[c.TRAIN], \
                                                self.acoustic_feature_filetype)
        label_dir = os.path.join(self.voice_resources.path[c.TRAIN], \
                                                self.input_label_filetype)
        
        ## Locate training script and default training config:
        script_dir = self.voice_resources.path[c.ACOUSTIC_MODELLING_SCRIPT]
        config_dir = self.voice_resources.path[c.ACOUSTIC_MODELLING_CONFIG]
        training_script = os.path.join(script_dir, self.acoustic_subrecipe+'.sh')
        default_config = os.path.join(config_dir, self.acoustic_subrecipe + '.cfg')

        ## Specialise the default config with settings made in the voice recipe, then
        ## write to bash config file for use by alignment script:
        train_config_fname = os.path.join(train_location, 'train.cfg')
        train_config = ConfigObj(default_config)
        train_config.update(self.training_settings)
        # get stream definitions from feature extractor too
        train_config.update(self.stream_definitions)
        write_bash_config(train_config, train_config_fname)
        
        ## Call the training script:
        command = """%s %s %s %s %s %s | tee %s/log.txt  \
                    | grep 'Aligner training'"""%(training_script, \
                            feature_dir, label_dir, self.hts_dir, train_location, \
                            train_config_fname, train_location)   
        success = os.system(command)
        if success != 0:
            sys.exit('Aligner training failed')
            
        ## Copy the aligner files that need to be preserved:
        assert os.path.isfile(os.path.join(train_location, "final_model", \
                                            "cmp.mmf")),"Aligner training failed"

        for item in ['cmp.mmf', 'config/general.conf','data/lexicon.txt', 'data/modellist.mono']:
            shutil.copy(os.path.join(train_location, 'final_model', item), self.model_dir)
        
        self.load() ## to get new model filenames into self.model's values



class StateAligner(SegmentAligner):
    '''
    Same as segment aligner, but adds nodes under segments with state timing info.
    Changes to process_utterance function:
        -- added -f to HVite call to get full state alignment
        -- added state_alignment=True to add_segments_from_label 
    '''
    def process_utterance(self, utt):
        if not self.trained:
            sys.exit('Aligner: must be trained before utterances can be processed.')
            
        if not (utt.has_external_data(self.acoustic_feature_filetype) and \
                                        utt.has_external_data(self.input_label_filetype)):
            print "No initial label and/or features for %s"%(utt.get('utterance_name'))
            utt.set("status", "alignment_failed")
            return            
            
        ## Try to align from audio:
        in_lab_dir = utt.get_dirname(self.input_label_filetype) ## dir (not file) for HVite
        out_lab_dir = utt.get_dirname(self.output_label_filetype)## dir (not file) for HVite

        feat_file = utt.get_filename(self.acoustic_feature_filetype) 
        logfile = utt.get_filename("align_log")  ## hardcoded!!!
        
        command = """%s/HVite -l %s -y %s -X %s -C %s -a -f -m -L %s -T 1 -o S -H %s \
                                                        %s %s %s > %s"""%(self.hts_dir,\
                     out_lab_dir, self.output_label_filetype, self.input_label_filetype, \
                    self.model['general.conf'], in_lab_dir, self.model['cmp.mmf'], \
                    self.model['lexicon.txt'], self.model['modellist.mono'], feat_file, \
                     logfile)
        os.system(command)
        
        time_lab = utt.get_filename(self.output_label_filetype)
        if not os.path.isfile(time_lab):
            print "No alignment produced for %s"%(utt.get('utterance_name'))
            utt.set("status", "alignment_failed")
            return
            
        ## If label has been made, merge its info into the utt XML:
        add_segments_and_states_from_label(utt, input_label=self.output_label_filetype,\
                                 target_nodes=self.target_nodes, \
                                 target_attribute=self.target_attribute   )
                                 
        propagate_start_and_end_times_up_tree(utt) ## to get e.g. woken start and end etc.
        
        remove_short_silent_segments(utt, target_attribute=self.target_attribute, \
                                        silence_symbol=self.silence_symbol,  \
                                        min_silence_duration=self.min_silence_duration)
            
        propagate_silence_tag_up_tree(utt, silence_symbol=self.silence_symbol, \
                                        target_attribute=self.target_attribute, \
                                        output_attribute=self.silence_tag)  
         

