#!/usr/bin/env python
# -*- coding: utf-8 -*-
## Project: Simple4All - January 2013 - www.simple4all.org 
## Contact: Oliver Watts - owatts@staffmail.ed.ac.uk
## Contact: Antti Suni - Antti.Suni@helsinki.fi


from UtteranceProcessor import *
from util.NodeProcessors import *
#from Utterance import *

#utterance_end_token = '_UTTEND_'  ## where to put things (constants) like this?

class PhraseMaker(UtteranceProcessor):

    def load(self):  
        ## get stuff from config, convert types and set defaults:
        self.silence_symbol = self.config.get('silence_symbol', 'sil')
        self.node_type_to_regroup=self.config.get('node_type_to_regroup', 'token')
        self.parent_node_type = self.config.get('parent_node_type', 'phrase')
        self.attribute_with_silence=self.config.get('attribute_with_silence', 'segment_name')
        
        
        ## derive some other attributes from them:
        self.target_xpath='//' + self.node_type_to_regroup
        
        
        
    def process_utterance(self, utt):
        
        ### Perform 2 'atomic' operations on the utterance:  

        ## add phrase start / end attributes  on tokens (True/False values):
        add_phrase_tags(utt, target_xpath=self.target_xpath, silence_symbol=self.silence_symbol, \
                                        attribute_with_silence=self.attribute_with_silence)
  
        ## Use those attributes to restructure the utterance using a generic
        ## restructuring function:
        restructure(utt, regroup_nodes_of_type=self.node_type_to_regroup, 
                    start_criterion="phrase_start", end_criterion="phrase_end", 
                    new_parent_type="phrase")
        

