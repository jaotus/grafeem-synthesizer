#!/usr/bin/env python
# -*- coding: utf-8 -*-
## Project: Simple4All - January 2013 - www.simple4all.org 
## Contact: Oliver Watts - owatts@staffmail.ed.ac.uk
## Contact: Antti Suni - Antti.Suni@helsinki.fi

# from naive.naive_util import *
# from VoiceElements import ConfiguredComponent

import os
import sys
import re
import shutil
import glob 
import fileinput
import subprocess

import default.const as c

from processors.NodeEnricher import NodeEnricher
from processors.UtteranceProcessor import UtteranceProcessor

from util.LookupTable import LookupTable

from naive.naive_util import readlist, writelist

class Lexicon(UtteranceProcessor):

    def load(self):

        self.target_nodes = self.config.get('target_nodes', "//token[@token_class='word']")
        self.input_attribute = self.config.get('input_attribute', 'norm_text')
        self.output_attribute = self.config.get('output_attribute', 'pronunciation')
        
        self.backoff_pronunciation = self.config.get('backoff_pronunciation', 'axr')
            ## ^--- use this if lookup and LTS fail for whatever reason...

        ## --- find and check required binaries ---
        self.lts_tool = os.path.join(self.voice_resources.path[c.BIN], 'g2p.py')
        tool_executable = os.access(self.lts_tool, os.X_OK)
        if not tool_executable:
            sys.exit('LTS tool %s doesn\'t exist or not executable'%(self.lts_tool ))


        ## Used if processor needs training:
        self.dictionary = self.config.get('dictionary', 'some_dictionary_name')

        ## Settings for LTS training:
        self.lts_ntrain = int(self.config.get('lts_ntrain', '0')) ## train on n words -- 0 means all.
        self.lts_gram_length = int(self.config.get('lts_gram_length', '3')) # 1: context independent graphones
        self.max_graphone_letters = int(self.config.get('max_graphone_letters', '2'))
        self.max_graphone_phones = int(self.config.get('max_graphone_phones', '2'))


        ## Try loading model:  # similar to acoustic model code--refactor and put this in UtteranceProcessor?
                               # Specific stuff would be the names of component of trained model.
        self.trained = True
        self.model_dir = os.path.join(self.get_location()) 

        if not os.path.isdir(self.model_dir):
            self.trained = False
            
        ## verify all the parts needed are present: if the model files exists, count it as trained:
        self.lexicon_fname = os.path.join(self.model_dir, 'lexicon.txt')
        self.lts_fname = os.path.join(self.model_dir, 'lts.model')
        self.phoneset_fname = os.path.join(self.model_dir, 'phones.table')
        self.onsets_fname = os.path.join(self.model_dir, 'onsets.txt')
        self.letter_fname = os.path.join(self.model_dir, 'letter.names')
        
        complete = True
        for component in [self.lexicon_fname, self.lts_fname, self.phoneset_fname, \
                                                    self.onsets_fname, self.letter_fname]:
            if not os.path.isfile(component):
                complete = False
                self.trained = False
                
        if self.trained:
            self.load_lexicon() # populate self.entries
            self.load_onsets()  # populate self.onsets
            self.phoneset = LookupTable(self.phoneset_fname, is_phoneset=True)
            self.load_letternames()  # populate self.letternames 
            
            ## lts_fname used directly in system call -- no load necessary
            
        ## TODO -- add custom entries from config file??

        ## Add locations for sequitur g2p to pythonpath:
        tooldir = os.path.join(self.voice_resources.path[c.BIN], '..')
        sitepackages_dir = glob.glob(tooldir + '/lib/python*/site-packages')
        assert len(sitepackages_dir) > 0
        sitepackages_dir = sitepackages_dir[0]
        
        ## Prepend this to relevant system calls -- using sequitur via python 
        ## would obviously be a lot neater. 
        self.g2p_path = 'export PYTHONPATH=%s:%s ; '%(sitepackages_dir, os.path.join(tooldir, 'g2p'))
        
        #sys.path.append(sitepackages_dir)
        #sys.path.append(os.path.join(tooldir, 'g2p'))
        
        
    def load_letternames(self):
        data = readlist(self.letter_fname)
        self.letternames = {}
        for line in data:
            line = line.strip(' \n')
            letter, pron = re.split('\s+', line, maxsplit=1)
            self.letternames[letter] = pron


    def convert_lexicon(self, files, format='festival'):
        
        print '     convert lexicon...'
        entries = {}
        seen_tags = {}  ## for reporting
        if format=='festival':
            for line in fileinput.input(files):
                line = line.strip(' \n')
                if line.startswith(';') or line == '' or line == 'MNCL':
                    continue ## ignore Scheme comment line and empty lines
                
                (headword, tags, pronun) = self.read_festival_lexentry(line)
                
                if headword not in entries:
                    entries[headword] = []
                entries[headword].append([tags, pronun])
                seen_tags[tags] = ''
        else:
            sys.exit('Unknown lexicon format: %s'%(format))
        
        print 'Tags in lexicon: ' 
        print seen_tags.keys()
        
        f = open(self.lexicon_fname, 'w')
        for head_word in sorted(entries.keys()):
            for (tag, pron) in entries[head_word]:
                f.write('%s\t%s\t%s\n'%(head_word, tag, pron))
        f.close() 
    
        self.entries = entries
        
        
    
    def load_lexicon(self):   
        
        assert os.path.isfile(self.lexicon_fname)
        items = readlist(self.lexicon_fname)
        self.entries = {}
        for item in items:
            (head,tag,pron) = item.split('\t')
            tag = tag.split(',')
            if head not in self.entries:
                self.entries[head] = []
            self.entries[head].append((tag, pron))
        
    def load_onsets(self):
        onsets = readlist(self.onsets_fname)
        onsets = [tuple(line.split(' ')) for line in onsets]
        self.onsets = dict(zip(onsets, onsets))
        
    def process_utterance(self, utt):
        for node in utt.xpath(self.target_nodes):
            assert node.has_attribute(self.input_attribute)
            word = node.get(self.input_attribute)
            
            word = word.lower()
            
            initialism_patt = '\A([a-z]\.)+\Z'
            if re.match(initialism_patt, word):
                pronunciation = self.get_initialism(word)
                node.set('phones_from', 'letter_prons')
                
            elif word in self.entries:
                node.set('phones_from', 'lex')
                if len(self.entries[word]) == 1:  ## unique, no disambig necessary
                    tag, pronunciation = self.entries[word][0]  ## for now take first
                else:
                    ## filter ambiguous pronunciations by first part of tag (POS):
                    wordpos = node.attrib['pos'].lower()
                    filtered = [(tag, pron) for (tag,pron) in self.entries[word] \
                                                                 if tag[0] == wordpos]
                    if len(filtered) == 0:
                        tag, pronunciation = self.entries[word][0] #if no POS matches, take first anyway
                    else:
                        tag, pronunciation = filtered[0] ## take first matching filtered dictionary entry
                        
            else:   
                pronunciation = self.get_oov_pronunciation(word)
                if pronunciation != None:
                    pronunciation = self.syllabify(pronunciation)
                    node.set('phones_from', 'lts')
                else:
                    pronunciation = self.backoff_pronunciation
                    node.set('phones_from', 'default')
            node.set(self.output_attribute, pronunciation)
            
    def count_onsets_and_codas(self):
        print '     count onsets and codas...'
        onsets = {}
        codas = {}
        for (entry, prons) in self.entries.items():
           
            for (tag, pron) in prons:
              
                pron = re.sub('\d','',pron) ## remove stress marks so we can look up vowels
                sylls = pron.split(' | ')
                for syll in sylls:
                    phones = syll.split(' ')
                    vowel_index = [i for (i,phone) in enumerate(phones) \
                            if self.phoneset.lookup(phone, field='vowel_cons')=='vowel']
                    if len(vowel_index) > 1:
                        print 'Multiple vowels found in syll %s in an entry for %s'%(syll, entry)
                        continue
                    if len(vowel_index) < 1:
                        print 'No vowels found in syll %s in an entry for %s'%(syll, entry)
                        continue
                    i = vowel_index[0]
                    onset = tuple(phones[:i])
                    coda = tuple(phones[i+1:])
                    if onset not in onsets:
                        onsets[onset] = 0
                    onsets[onset] += 1
                    if coda not in codas:
                        codas[coda] = 0
                    codas[coda] += 1
        self.onsets = onsets
        self.codas = codas


    def get_initialism(self, form):
        letters = form.lower().strip(' .').split('.')
        pronunciation = []
        for letter in letters:
            pronunciation.append(self.letternames[letter] )
        pronunciation = ' | '.join(pronunciation)
        return pronunciation
        
    def syllabify(self, phonestring):
        '''
        Syllabify with maximum legal (=observed) onset.
        Take "e g z a1 m" 
        return "e g | z a1 m"
        '''
        assert '|' not in phonestring
        plain = re.sub('\d','',phonestring) ## remove stress marks so we can look up vowels
        plainphones = plain.split(' ')
        phones = phonestring.split(' ')
        vowel_indexes = [i for (i,phone) in enumerate(plainphones) \
                            if self.phoneset.lookup(phone, field='vowel_cons')=='vowel']

        if len(vowel_indexes) > 0:  ## else add nothing to phones and return that.
        
            start = vowel_indexes[0]+1
            
            for end in vowel_indexes[1:]:
                
                if start == end:  ## juncture between 2 vowels as in 'buyer'
                    best_split = start
                else:
                    split_scores = []
                    for split in range(start, end):
                        first_part = tuple(plainphones[start:split])
                        second_part = tuple(plainphones[split:end])
                    
                        ## Take maximum legal onset:
                        if second_part in self.onsets:
                            score = len(second_part)
                        else:
                            score = -1
                    
                        ## Older version: score is sum of onset and coda freqs:
                        # score = self.codas.get(first_part, 0) + self.onsets.get(second_part, 0)
                    
                        split_scores.append((score, split))
                    split_scores.sort()
                    
                    best_split = split_scores[-1][1]
                phones[best_split] = '| ' + phones[best_split]

                start = end + 1

        return ' '.join(phones)

  
    def train(self, corpus, text_corpus):

        dict_location = os.path.join(self.voice_resources.path[c.LANG], 'labelled_corpora', self.dictionary)

        ## phoneset
        phonetable_file = glob.glob(os.path.join(dict_location, '*.table'))[0] ## take first 
        shutil.copy(phonetable_file, self.phoneset_fname)
        ## load phoneset now for converting lexicon:
        self.phoneset = LookupTable(self.phoneset_fname, is_phoneset=True)

        ## letter pronunciations
        letter_file = os.path.join(dict_location, 'letter.names')
        assert os.path.isfile(letter_file)
        shutil.copy(letter_file, self.letter_fname)
        self.load_letternames()  # populate self.letternames 
        
        ## lexicon
        dict_files = [f for f in glob.glob(os.path.join(dict_location, '*')) \
                    if f.endswith('.out')] 
                    
                    ## exclude cmudict extensions:  ## or f.endswith('.scm') ]  
                    ## glob doesn't support {} for .{out,scm}
                    
        assert dict_files != [],'No lexicon files found at %s'%(dict_location)
        self.convert_lexicon(dict_files)
        
        ## onsets
        self.count_onsets_and_codas() 
        onset_strings = [' '.join(onset) for onset in self.onsets.keys()]
        writelist(onset_strings, self.onsets_fname)
        
        ## G2P
        train_file = os.path.join(self.get_training_dir(), 'train_data.txt')
        self.make_sequitur_train_data(train_file)
        self.train_sequitur_g2p(train_file)

        

    def make_sequitur_train_data(self, train_file):
        '''Write entries to file for training g2p, append stress to vowel symbols'''
        lines = []
        for (head, entry) in self.entries.items():
            for (tags, pronun) in entry:
                train_phones = pronun.replace(' | ', ' ').split(' ') ## list of phones w/o syllab
                line = ' '.join([head] + train_phones) + '\n'
                lines.append(line)
        
        if self.lts_ntrain > 0:
            lines = lines[:self.lts_ntrain]
                
        f = open(train_file, 'w')
        for line in lines:
            f.write(line)
        f.close()
        print 'Wrote %s'%(train_file)
        
    def train_sequitur_g2p(self, train_file):
        '''Currently use system call -- TODO: keep this all in python?'''

        lts_model = self.lts_fname
        print 'Training LTS with sequitur...'
        ## train unigram model:
        n = 1
        comm = '%s %s --train %s -s 1,%s,1,%s --devel 5%% --write-model %s_%s > %s.log'%(self.g2p_path, \
                            self.lts_tool, train_file, self.max_graphone_letters, \
                            self.max_graphone_phones, lts_model, n, lts_model)
        print comm
        os.system(comm)
        n += 1
        while n <= self.lts_gram_length:
            comm = '%s %s --model %s_%s --ramp-up --train %s --devel 5%% --write-model %s_%s >> %s.log'%(
                          self.g2p_path, self.lts_tool, lts_model, n-1, train_file, lts_model, n, lts_model)
            print comm
            os.system(comm)  
            n += 1
        shutil.copy('%s_%s'%(lts_model, self.lts_gram_length), lts_model)
        self.lts_model = lts_model
            
    def get_oov_pronunciation(self, word):
        '''Currently use system call -- TODO: keep this all in python?'''
        
        word = word.lower()
        #escaped_word = "'" + word.replace("'", "'\\''") + "'" ## escape ' for shell command
        escaped_word = "'" + word.replace("'", "") + "'"  ## strip apostrophe
        comm = '%s echo %s | %s  --model %s --apply -'%(self.g2p_path,  \
                                                    escaped_word, self.lts_tool, self.lts_fname)
    
        pronun = subprocess.check_output(comm, shell=True, stderr=subprocess.STDOUT)
        if 'failed to convert' in pronun:
            print comm
            print 'WARNING: couldnt run LTS for %s'%(word)
            return None
        
        ## remove the 'stack usage' output line -- its position varies:
        pronun = pronun.strip(' \n').split('\n')
        assert len(pronun) == 2,str(pronun)
        for line in pronun:
            if 'stack usage' not in line:
                pronun = line
                
        (outword, pronun) = re.split('\s+', pronun, maxsplit=1)
        assert outword == word.replace("'",""),'don\'t match: %s and %s'%(outword, word)
        return pronun
        

    
    
    
    def read_festival_lexentry(self, string):

        ## TODO: handle simple pronunciations better

        string = re.sub('(\A\s*\(\s*|\s*\)\s*\Z)', '', string) ## strip outer brackets
    
        entry = re.split('(\A"[^"]+\")', string) ## brackets to return chunks as well as splits
    
        entry = [chunk for chunk in entry if chunk != ''] ## filter intial ''
        assert len(entry) == 2,entry
        word, pronun = entry
    
        word = word.strip('"')
        pronun = pronun.strip(' ')
        ## tag might be a string or bracketed sequence:
    
        if pronun[0] == '(':
            pronun = re.split('\)\s*\(', pronun,maxsplit=1) # re.split('(\([^)]+\))',pronun)
        else:
            pronun = re.split('\s+',pronun,maxsplit=1)
        pronun = [chunk for chunk in pronun if chunk != '']
    
        assert len(pronun) == 2,pronun
        tag, all_syllables = pronun
    
        tag = tag.strip('() ')

        pronun = []
        
        ## is it a simple pronunciation (later addition, no syll and stress appended to vowel)? -- :
        if all_syllables.count(')') == 1 and all_syllables.count('(') == 1:
            phones = all_syllables.strip('()')
            stress = '1' ## dummy
            pronun.append(phones)
            
        else:

            syllables = re.split('\)\s*\(', all_syllables)
            syllables = [syll.strip(' ()') for syll in syllables]

            for syll in syllables:
                phones, stress = re.split('\)\s*', syll)
                phones = phones.split(' ')
                stressed_phones = []
                for phone in phones:
                    if self.phoneset.lookup(phone, field='vowel_cons') == 'vowel':
                        phone = phone + stress
                    stressed_phones.append(phone)
                pronun.append(' '.join(stressed_phones))
        pronun = ' | '.join(pronun)

        ## parse tag into either [POS] or [POS, disambig] or [POS, disambig, variant_tag]
        if ' ' in tag:
            tag = tag.split(' ')
            assert len(tag) == 2 # in [2,3]
        else:
            tag = [tag]
        tag = ','.join(tag)  ## tuple(tag)

        return (word, tag, pronun)

    
class SyllStressAdder(NodeEnricher):
    def load(self):
        NodeEnricher.load(self)
        self.target_nodes = self.config.get('target_nodes', "//syllable")
        self.input_attribute = self.config.get('input_attribute', 'pronunciation')
        self.output_attribute = self.config.get('output_attribute', 'stress')
    def enriching_function(self, input):
        stress_marks = re.findall('\d+', input)
        stress_marks = [int(mark) for mark in stress_marks]
        if len(stress_marks) > 1:
            print 'Warning: multiple stress marks for syllable %s'%(input)
        if len(stress_marks) < 1:
            print 'Warning: no stress marks for syllable %s'%(input)
        ## add string prefix so feature is treated as categorical:
        return 'stress_' + str(max(stress_marks + [0]))

class PhoneticFeatureAdder(UtteranceProcessor):
    def load(self):
        
        self.target_nodes = self.config.get('target_nodes', "//phone")
        self.input_attribute = self.config.get('input_attribute', 'pronunciation')
        self.dictionary = self.config.get('dictionary', 'some_dictionary_name')
        
        self.phone_table_file = os.path.join(self.get_location(), 'phones.txt') 

        try:
            self.phone_table = LookupTable(self.phone_table_file, is_phoneset=True)
            self.trained = True
            
        except:
            self.trained = False
    
    
    def train(self, corpus, text_corpus):
        dict_location = os.path.join(self.voice_resources.path[c.LANG], 'labelled_corpora', self.dictionary)
        assert os.path.isdir(dict_location),'Dictionary directory %s doesn\'t exist'%(dict_location)
        original_phonetable_file = glob.glob(os.path.join(dict_location, '*.table'))[0] ## take first 
        shutil.copy(original_phonetable_file, self.phone_table_file)
    
        self.load()    
    
    def process_utterance(self, utt):
        for node in utt.xpath(self.target_nodes):
            assert node.has_attribute(self.input_attribute)
            phone = node.get(self.input_attribute)
            
            for feature in self.phone_table.fields:
                value = self.phone_table.lookup(phone, field=feature)
                node.set(feature, value)


if __name__=="__main__":

    

    print get_spans_on_one_level('("checkpoints" nil (((ch eh k) 1) ((p oy n t s) 1)))')
