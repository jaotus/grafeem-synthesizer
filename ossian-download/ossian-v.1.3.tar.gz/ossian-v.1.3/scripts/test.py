#!/usr/bin/env python

from naive.naive_util import *
import glob

for f in glob.glob('/Users/owatts/repos/simple4all/TASSAL/branches/cleaner_june_2013/train/en/speakers/tundra_1hour/baseline05/cmp/livingalone_*.cmp'):
    print f + " " + str(get_htk_filelength(f))
    

